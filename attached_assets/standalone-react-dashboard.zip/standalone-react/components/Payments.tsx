const Payments = () => (
  <div>
    <h2 className="text-lg font-semibold mb-2">Payments</h2>
    <p>Last Payment: ₹1500 on May 10</p>
    <p>Next Due: ₹1500 on June 10</p>
  </div>
);
export default Payments;
