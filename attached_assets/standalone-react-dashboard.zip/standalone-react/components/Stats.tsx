const Stats = () => (
  <div>
    <h2 className="text-lg font-semibold mb-2">Player Stats</h2>
    <p>Attendance: 92%</p>
    <p>Batting Skill: ⭐⭐⭐⭐</p>
    <p>Bowling Skill: ⭐⭐⭐</p>
  </div>
);
export default Stats;
